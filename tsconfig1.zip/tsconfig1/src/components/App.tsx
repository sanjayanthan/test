import{BrowserRouter as Router,Routes,Route}from 'react-router-dom'
import Application from '../pages/application'
import District from '../pages/district'
import Region from '../pages/region'
import Store from '../pages/store'

function App() {

  return (
    <>
      <div>
        <Router>
          <Routes>
            <Route path='/' element={<Application/>}/>
            <Route path='/District' element={<District/>}/>
            <Route path='/Region' element={<Region/>}/>
            <Route path='/Store' element={<Store/>}/>
          </Routes>
        </Router>
      </div>
    </>
  )
}

export default App
