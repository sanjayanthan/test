
# Standard Documentation

[Developer Guide](https://confluence.dolgen.net/display/DEVOP/Developer+Guide)  
[Gitlab Pipeline](https://confluence.dolgen.net/display/DEVOP/Gitlab+Pipeline+Stages)  
[SDLC](https://confluence.dolgen.net/display/DEVOP/Methods+and+Tools#MethodsandTools-SystemDeliveryLifeCycle)  
[Tools](https://confluence.dolgen.net/display/DEVOP/Tools+Overview)  
[Standards](https://confluence.dolgen.net/display/DEVOP/Standards)  
[Methods and Tools Space](https://confluence.dolgen.net/display/DEVOP/Methods+and+Tools)  
